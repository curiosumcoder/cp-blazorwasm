﻿namespace ba1.Models
{
    public class Northwind
    {
        public List<Product> Products { get; set; } = new List<Product>();
    }
}
